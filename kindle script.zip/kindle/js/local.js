 
$(document).ready(function(){

    $("#searchsubmit").submit(function(e) {
  e.preventDefault();
$.ajax({
url:'api.php',
method: 'GET',
dataType:'JSON',
data:{'s_key': $("#search").val()}
,beforeSend: function(loading){
$("#searchBtn").html('Loading...');


},success: function(data){

if(data.error == 'not_found_result'){
alert('not found any result');
$("#searchBtn").html('Search');

}else{

$("#viewResults").show(500);
$("#searchBtn").fadeOut(500);   

$("#jsonResponse").attr('value',''+ JSON.stringify(data) +'');
    $(this).unbind(e);

//$(".switchform").animate({ height: 'hide', opacity: 'hide' }, 'slow');   






/*
$("#jsonResponse").attr('value',''+ JSON.stringify(data) +'');
$.ajax({
url:'results.php',
data:{'jsonResponse':$("#jsonResponse").val()},
method: 'POST',
success: function(results_xhr){
$(".switchform").animate({ height: 'hide', opacity: 'hide' }, 'slow');   
$(".s006").html(results_xhr);

}
}); 
*/
}
},error: function(xhrErr){
$("#searchBtn").html('Try Again');

}


});



});






});  


